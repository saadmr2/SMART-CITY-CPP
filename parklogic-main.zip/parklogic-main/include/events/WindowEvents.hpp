#pragma once
struct WindowResizeEvent {
  int width, height;
};
struct WindowCloseEvent {};
